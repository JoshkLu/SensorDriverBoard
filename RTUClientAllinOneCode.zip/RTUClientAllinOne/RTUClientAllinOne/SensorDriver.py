
from lib.ModbusClientRTU import ModbusClientRTU
import lib.constants
import time
import threading
import events

class SensorDriver(object):
    _HOST = "127.0.0.1"
    _PORT = 5001
    _timeInterval = 300.0
    A = 0
    B = 0
    C = 0
    D = 0
    E = 0
    F = 0
    _debug = False
    running = False
    client = None
    t1 = None
    events = None

    def __init__(self,host,port,timeInterval=300,debug=False):
        self._HOST = host
        self._PORT = port
        self._timeInterval = timeInterval
        self.events = events.Events()

        if debug == True:
            self._debug = True

        self.client = ModbusClientRTU(self._HOST,self._PORT,debug=self._debug,auto_open=True)

        #set UID to 1
        self.client.unit_id(1)

        self.t1 = threading.Thread(target=self.Start)
        self.t1.daemon = True
        self.t1.start()

    def Start(self):
        self.running = True
        if not self.client.is_open():
            if self._debug == True:
                print("Connect to " + self._HOST + ":" + str(self._PORT))
                self.events.on_change("Connect to " + self._HOST + ":" + str(self._PORT))
            
        while self.running:
            # open or reconnect TCP to server
            if not self.client.is_open():
                if not self.client.open():
                    if self._debug == True:
                        print("unable to connect to " + self._HOST + ":" + str(self._PORT))
                        self.events.on_change("unable to connect to " + self._HOST + ":" + str(self._PORT))
                    # if open() is ok, read register (modbus function 0x03)
            if self.client.is_open() :
                # read 6 registers at address 0, store result in regs list
                regs = self.client.read_holding_registers(0, 6)
                if regs:
                    self.A = int(regs[0])
                    self.B = int(regs[1])
                    self.C = int(regs[2])
                    self.D = int(regs[3])
                    self.E = int(regs[4])
                    self.F = int(regs[5])
                    if self._debug == True:print(" A   B   C   D   E   F   ")
                    if self._debug == True:
                        print(regs)
                        self.events.on_change("A=" + str(self.A) + " , B=" + str(self.B) + " , C=" + str(self.C) + " , D=" + str(self.D) + " , E=" + str(self.E) + " , F=" + str(self.F))
            if self.client.last_error() > 0 :
                if self._debug == True:
                    print("ErrorCode: " + lib.constants.ErrorCodelist[self.client.last_error()])
                    self.events.on_change("ErrorCode: " + lib.constants.ErrorCodelist[self.client.last_error()])
            # sleep 1s before next polling
            time.sleep(self._timeInterval * 0.001)

    def Stop(self):
        self.running = False
        self.t1.join(1)

    def Ask(self,lists):
        ans = []
        for item in lists:
            if item == 'A' :ans.append(self.A)
            if item == 'B' :ans.append(self.B)
            if item == 'C' :ans.append(self.C)
            if item == 'D' :ans.append(self.D)
            if item == 'E' :ans.append(self.E)
            if item == 'F' :ans.append(self.F)
        return ans

    def SetInterVal(self,Val_ms):
        self._timeInterval = Val_ms

    def Setdebug(self, state):
        """set debug mode
        :param state: debug state or None for get value
        :type state: bool

        """
        self._debug = bool(state)
        if self.client != None:
            self.client.debug = self._debug
