# -*- coding: utf-8 -*-
import sys
from datetime import datetime
import time
import json
import struct
from PyQt5 import QtCore, QtGui, QtWidgets
from DemoGUI import Ui_MainWindow

from SensorDriver import SensorDriver

# HOST & PORT
with open('HOST_PORT.json', 'r', encoding='utf-8') as f:
    HOST_PORT = json.load(f)

class MyThread(QtCore.QThread):
    updated = QtCore.pyqtSignal(str)

    def run(self,reason):
        self.updated.emit(reason)

class MainWindow(QtWidgets.QMainWindow):
    A = 0
    B = 0
    C = 0
    D = 0
    E = 0
    F = 0
    running = False
    SensorDrives = None
    _debug = False
    _thread = None

    def __init__(self):     # 初始化元件
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.setWindowTitle("DemoGUI V1.0")

        self.HOST = HOST_PORT['HOST']
        self.PORT = int(HOST_PORT['PORT'])

        self._thread = MyThread(self)
        self._thread.updated.connect(self.updateText)

        self.ui.BtnConnect.clicked.connect(self.BtnConnectEvent)
        self.ui.BtnDisconnect.clicked.connect(self.BtnDisconnectEvent)
        self.ui.BtnRefresh.clicked.connect(self.BtnRefreshEvent)
        self.ui.chkDebug.clicked.connect(self.chkDebugEvent)

        self.updateText(self.GetNowTime() + "Program Start!")

    def BtnConnectEvent(self):        # 連線按鈕
        self.running = True
        # Step 1 連接一個 SensorDrives 元件
        ''' 
                                           輪詢間隔(ms)   
                            IP           port     Debug=True/False 是否有print底層封包
            SensorDriver('192.168.1.200',5000,500,True)
        '''
        self.SensorDrives = SensorDriver(self.HOST,self.PORT,500,self._debug)
        self.SensorDrives.events.on_change += self.PassMsgEvent

        self.ui.BtnConnect.setEnabled(False)
        self.updateText(self.GetNowTime() + "Connect to (" + self.HOST + ":" + str(self.PORT) + ")")

    def BtnDisconnectEvent(self):     # 斷線按鈕
        self.running = False
        self.SensorDrives.Stop()
        self.ui.BtnConnect.setEnabled(True)
        self.updateText(self.GetNowTime() + "Disconnect.")
        
    def BtnRefreshEvent(self):     # 刷新按鈕
        if not self.SensorDrives == None:
            self.A,self.B,self.C,self.D,self.E,self.F = self.SensorDrives.Ask(['A','B','C','D','E','F'])
        TmpMsg = "A=" + str(self.A) + " , B=" + str(self.B) + " , C=" + str(self.C) + " , D=" + str(self.D) + " , E=" + str(self.E) + " , F=" + str(self.F)
        self.updateText(TmpMsg)
        self.ui.txtA.setText(str(self.A))
        self.ui.txtA.setAlignment(QtCore.Qt.AlignHCenter)
        self.ui.txtB.setText(str(self.B))
        self.ui.txtB.setAlignment(QtCore.Qt.AlignHCenter)
        self.ui.txtC.setText(str(self.C))
        self.ui.txtC.setAlignment(QtCore.Qt.AlignHCenter)
        self.ui.txtD.setText(str(self.D))
        self.ui.txtD.setAlignment(QtCore.Qt.AlignHCenter)
        self.ui.txtE.setText(str(self.E))
        self.ui.txtE.setAlignment(QtCore.Qt.AlignHCenter)
        self.ui.txtF.setText(str(self.F))
        self.ui.txtF.setAlignment(QtCore.Qt.AlignHCenter)
    
    def chkDebugEvent(self):
        self._debug = self.ui.chkDebug.isChecked()
        if self.SensorDrives != None:
            self.SensorDrives.Setdebug(self._debug)

    def GetNowTime(self):
        Msgtime = datetime.now().strftime("%H:%M:%S ")
        return Msgtime
    
    def PassMsgEvent(self,reason):
        self._thread.run(reason)

    def updateText(self,reason):
        self.ui.Txtlog.appendPlainText(self.GetNowTime() + reason)
        #移動到 顯示 最後行
        self.ui.Txtlog.moveCursor(QtGui.QTextCursor.End)

if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
