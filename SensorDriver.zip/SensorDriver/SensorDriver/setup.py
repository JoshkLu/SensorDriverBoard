from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize

extensions = [
    Extension(
    "SensorDriver",["SensorDriver.py"]
    ),
    Extension(
        "lib.ModbusClientRTU",["lib/ModbusClientRTU.py"]
    ),
    Extension(
        "lib.constants",["lib/constants.py"]
    ),
    Extension(
        "lib.utils",["lib/utils.py"]
    )
]

setup(
    name = "SensorDriver",
    ext_modules=cythonize(extensions),
)